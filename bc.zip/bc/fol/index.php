
<!DOCTYPE html>
<!--[if IEMobile 7 ]><html class="no-js iem7"><![endif]-->
<!--[if lt IE 9]><html class="no-js lte-ie8"><![endif]-->
<!--[if (gt IE 8)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!--><html class="no-js" lang="en"><!--<![endif]-->
<head>
  <title>Bcamp Login</title>
  <link rel="stylesheet" type="text/css" href="css/fonts.css" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link rel="stylesheet" type="text/css" href="css/bcamp.css" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-FRAME-Options" content="SameOrigin">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
 
  
</head>

  <body class="people answer">
    <header role="banner" id="top"> 
   <? include("components/header.inc.php"); ?>
</header>
    <div class="content">
    
              <section class="sheet workspace">
         
<form accept-charset="UTF-8" action="/session" method="post" > 
              
              

              <div id="user_name_login">
                  <h1>Wanna be organise wtih <strong>Bcamp ID</strong></h1>
                  <center><img src="img/img-iconmap2.png" /></center>
                <h1>Last year alone, Basecamp helped over 285,000 companies finish more than 2,000,000 projects.</h1>
                  
                  <h2>What’s Basecamp?</h2>
                  <p>Basecamp makes it easy for people in different roles with different responsibilities to communicate and work together. It’s a place to share files, have discussions, collaborate on documents, assign tasks, and check due dates. Basecamp stores everything securely and can be accessed at anytime from anywhere. <a href="/story">Read a short story about how Basecamp was born.</a></p>
<hr />
              <div id="signin_button1"> 
                  <a class="action_button button" href="signin.php" name="button" type="submit">click here to Sign in</a>
              </div>
</form>
                  


              </section>
            
            
          
            
            
             
        
  </article>
</section>

      <footer role="contentinfo">
  <? include("components/footer.inc.php"); ?>
</footer>

    </div>
  </body>
</html>