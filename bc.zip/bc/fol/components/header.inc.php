<nav role="navigation">
    <ul> 
      <li><a href="index.php">Home</a></li>
      <li><a href="signin.php">Signin</a></li>
      <li><a href="register.php">Register</a></li>
      <li><a href="contactus">Contactus</a></li>
    </ul>
  </nav>