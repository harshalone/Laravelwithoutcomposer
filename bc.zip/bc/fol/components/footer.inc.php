<ul>
    <li class="faq"><a href="/help/faq">FAQ</a> <span class="tooltip">Find all of the answers to commonly asked questions about Basecamp.</span></li>
    <li class="guides"><a href="/help/guides">Guides</a> <span class="tooltip">Dig into our fully-packed guides to learn Basecamp inside and out.</span></li>
    <li class="vids"><a href="/help/videos">Videos</a> <span class="tooltip">Short, fun clips showing tips, tricks, and shortcuts to get the most out of Basecamp.</span></li> 
  </ul> 