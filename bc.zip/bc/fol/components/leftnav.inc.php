<ul>
  <h3>Working with People</h3> 
    <li><a href="/help/guides/people/project-access">then you need US</a></li> 
</ul>