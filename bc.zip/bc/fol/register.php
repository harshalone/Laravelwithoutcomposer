
<!DOCTYPE html>
<!--[if IEMobile 7 ]><html class="no-js iem7"><![endif]-->
<!--[if lt IE 9]><html class="no-js lte-ie8"><![endif]-->
<!--[if (gt IE 8)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!--><html class="no-js" lang="en"><!--<![endif]-->
<head>
  <title>Bcamp Register</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/bcamp.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-FRAME-Options" content="SameOrigin">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
 
  
</head>

  <body class="people answer">
    <header role="banner" id="top"> 
   <? include("components/header.inc.php"); ?>
</header>
    <div class="content">
      
          <aside>
           <? include("components/leftnav.inc.php"); ?>
          </aside>
          
            
              <section class="sheet answer">
         
<form accept-charset="UTF-8" action="/session" method="post" > 
              
              

              <div id="user_name_login">
                  <h1>Register with <strong>Bcamp ID</strong></h1>

                <p>
                    <span class="overlay_wrapper"><label for="username" class="overlabel">Your full name</label><br/>
                    <input class="login-input" name="email" title="Username or email" type="text"></span>
                </p>
                <p>
                    <span class="overlay_wrapper"><label for="username" class="overlabel">Company or organization</label><br/>
                    <input class="login-input" name="email" title="Username or email" type="text"></span>
                </p>
                  <p>
                    <span class="overlay_wrapper"><label for="username" class="overlabel">Email</label><br/>
                    <input class="login-input" name="email" title="Username or email" type="text"></span>
                </p>
                <p>
                    <span class="overlay_wrapper"><label for="username" class="overlabel">Password</label><br/>
                    <input class="login-input" name="email" title="Username or email" type="password"></span>
                </p>
                 
              </div> 

              <div id="remember_container">
                <input checked="checked" id="remember_me" name="remember_me" type="checkbox" value="1"> <label for="remember_me">Remember me on this computer</label>
              </div>

<hr />
              <div id="signin_button1"> 
                  <button class="action_button button" data-behavior="create_document" name="button" type="submit">Sign in</button>
              </div>
</form>
                  


              </section>
            
            
          
            
            
             
        
  </article>
</section>

      <footer role="contentinfo">
  <? include("components/footer.inc.php"); ?>
</footer>

    </div>
  </body>
</html>