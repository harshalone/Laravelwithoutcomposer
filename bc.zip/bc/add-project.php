<!DOCTYPE html> 
    <head>
		<? include("components/head.inc.php"); ?>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		<div class="help fix">
		  <a href="help.php"><img src="assets/img/help.png" alt=""/></a>
		</div>
		
        <div class="header_area fix">
		  <? include("components/header.inc.php"); ?>
		</div><!--End heading area-->
		
         <div class="maincontent_area fix">
		   <div class="mainocntent structure column fix">
               <div class="workspace">
                <form class="add-project-form">
                    <p> 
                        <input class="projecttitle" name="email" title="Username or email" type="text" value="Name the project" />
                    </p>
                    <p> 
                        <textarea name="email" title="Username or email" type="text" value="Name the project">Add a description or extra details (optional)</textarea>
                    </p> 
                    <header>
                        <h3><strong>Invite people to your team</strong></h3>
      <p>Anyone on your team will see everything posted to this project. Every message, to-do list, file, event, and text document.</p> 
    </header>
                    <p> 
                        <input class="emailpeople" name="email" title="Username or email" type="text" placeholder="email address" />
                    </p>
                    <p> 
                        <input class="emailpeople" name="email" title="Username or email" type="text" placeholder="email" />
                    </p>
                    <p> 
                        <input class="emailpeople" name="email" title="Username or email" type="text" placeholder="email" />
                    </p>
                    <hr />
                  <div id="signin_button1"> 
                      <button class="action_button button" data-behavior="create_document" name="button" type="submit">Create Project
                      </button>
                  </div>
                    
                </form>
               </div>
               <footer class="addprojectpot">
                  <div>
                    <header>
                      <strong>Project Templates</strong>
                    </header>

                    <p>Find yourself creating the same project over and over? Save time and use a project template instead. Every message, to-do list, file, text document, and date will be added to your project automatically.<a class="decorated" data-method="post" data-remote="true" href="template.php" rel="nofollow">Create your first template...</a></p>
                  </div>
                </footer>
		  </div>	   
	  </div><!--End maincontent-->
	   
    </body>
</html>
