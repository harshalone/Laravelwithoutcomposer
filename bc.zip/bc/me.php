<!DOCTYPE html> 
    <head>
		<? include("components/head.inc.php"); ?>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		<div class="help fix">
		  <a href="help.php"><img src="assets/img/help.png" alt=""/></a>
		</div>
		
        <div class="header_area fix">
		  <? include("components/header.inc.php"); ?>
		</div><!--End heading area-->
		
         <div class="maincontent_area fix">
		   <div class="mainocntent structure column fix">
			   <div class="content_head_area fix">
			    <div class="content_head column fix">
				  <div class="amy_water floatleft fix" >
				    <img class="floatleft fix" src="assets/img/amy.png" alt=""/>
					 <h2>amy water</h2>
					 <a href="#">amywater@vsell.co.uk</a>
					 <p>Last active 4 hours ago</p>
				  </div>
		   
				  <div class="personal_info floatleft fix ">
				    <h4><a href="#">Update to your personal info</a></h4>
					<p>Name, phooto, time zone, password..</p>
				  </div>
				  <div class="basecamp_setting floatright fix">
				    <h4><a href="#">My Basecamp setting</a></h4>
					<p>Notifications, subscriptions..</p>
				  </div>
				 </div> 
			   </div><!--End content head--> 
			
			<div class="latest_activity_area fix">
			   <div class="latest_activity fix">
			     <h2>Your latest activity across all projects</h2>
				 
				   <div class="time fix floatleft">
				     <ul>
					   <li>11.37am &nbsp;</li>
					   <li>Dec 3</li>
					   <li>Dec 3</li>
					   <li>Dec 3</li>
					   <li>Dec 3</li>
				     </ul>
				   </div>
				   <div class="post floatleft fix">
				     <ul>
					   <li>You posted a message:&nbsp;<span><a href="#">this is another discussion</a></span>&nbsp;in CWH test project</li>
					   <li>You posted a message:&nbsp;<span><a href="#">this is another discussion</a></span>&nbsp;in CWH test project</li>
					   <li>You posted a message:&nbsp;<span><a href="#">this is another discussion</a></span>&nbsp;in CWH test project</li>
					   <li>You posted a message:&nbsp;<span><a href="#">this is another discussion</a></span>&nbsp;in CWH test project</li>
					   <li>You posted a message:&nbsp;<span><a href="#">this is another discussion</a></span>&nbsp;in CWH test project</li>
				     </ul>
				   </div>
				   <div style="clear:both"></div>
				 <p><a href="#">See all your activity</a></p>
			   </div><!--End latest activity-->
			   
			   <div class="completed_todo fix">
			     <h2>You completed a to do</h2>
				 <div class="bradcumb fix">
				   <p>To do list basics&nbsp;-&nbsp;Explore Basecamp</p>
				 </div>
				 <div class="todo fix">
				   <p>This to do has a due date. <span>completed Dec 3</span></p>
				 </div>
			   </div>
			  </div> 
		  </div>	   
	  </div><!--End maincontent-->
	  
	  <!--Javascript-->
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	  <script type="text/javascript" src="js/jquery.slicknav.min.js"></script>
	  <script>
			$(function(){
				$('#nav').slicknav({
				 label : 'Menu',
				 prependTo : '.mainmenu_area'
				});
			});
		</script>
    </body>
</html>
