<!DOCTYPE html> 
    <head>
		<? include("components/head.inc.php"); ?>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		<div class="help fix">
		  <a href="help.php"><img src="assets/img/help.png" alt=""/></a>
		</div>
		
        <div class="header_area fix">
		  <? include("components/header.out.php"); ?>
		</div><!--End heading area-->
		
         <div class="maincontent_area fix">
		   <div class="mainocntent structure column fix">
			            
                <form class="formbox" accept-charset="UTF-8" action="/session" method="post" >  

                  <div id="user_name_login">
                    <h1>Sign in with your <strong>Bcamp ID</strong></h1>

                    <p>
                        <span class="overlay_wrapper"><label for="username" class="overlabel">Your full name</label><br/>
                        <input class="login-input" name="email" title="Username or email" type="text"></span>
                    </p>
                    <p>
                        <span class="overlay_wrapper"><label for="username" class="overlabel">Company name</label><br/>
                        <input class="login-input" name="email" title="Username or email" type="text"></span>
                    </p>
                    <p>
                        <span class="overlay_wrapper"><label for="username" class="overlabel">Email</label><br/>
                        <input class="login-input" name="email" title="Username or email" type="text"></span>
                    </p>
                    <p>
                        <span class="overlay_wrapper"><label for="username" class="overlabel">Password</label><br/>
                        <input class="login-input" name="email" title="Username or email" type="password"></span>
                    </p>

                  </div> 

                  <div id="remember_container">
                    <input checked="checked" id="remember_me" name="remember_me" type="checkbox" value="1"> <label for="remember_me">Remember me on this computer</label>
                  </div>

                  <hr />
                  <div id="signin_button1"> 
                      <button class="action_button button" data-behavior="create_document" name="button" type="submit">Sign in
                      </button>
                  </div>
                </form>
           
			
			 
		  </div>	   
	  </div><!--End maincontent-->
	  
	  <!--Javascript-->
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	  <script type="text/javascript" src="js/jquery.slicknav.min.js"></script>
	  <script>
			$(function(){
				$('#nav').slicknav({
				 label : 'Menu',
				 prependTo : '.mainmenu_area'
				});
			});
		</script>
    </body>
</html>
