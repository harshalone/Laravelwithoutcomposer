<!DOCTYPE html> 
    <head>
		<? include("components/head.inc.php"); ?>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		<div class="help fix">
		  <a href="help.php"><img src="assets/img/help.png" alt=""/></a>
		</div>
		
        <div class="header_area fix">
		  <? include("components/header.out.php"); ?>
		</div><!--End heading area-->
		
         <div class="maincontent_area fix">
		   <div class="mainocntent structure column fix">
			 <div class="workspace">
                 
                  <div id="user_name_login">
                  <h1>Wanna be organise wtih <strong>Bcamp ID</strong></h1>
                  <center><img src="assets/img/img-iconmap2.png" /></center>
                <h1>Last year alone, Basecamp helped over 285,000 companies finish more than 2,000,000 projects.</h1>
                  
                  <h2>What’s Basecamp?</h2>
                  <p>Basecamp makes it easy for people in different roles with different responsibilities to communicate and work together. It’s a place to share files, have discussions, collaborate on documents, assign tasks, and check due dates. Basecamp stores everything securely and can be accessed at anytime from anywhere. <a href="/story">Read a short story about how Basecamp was born.</a></p>
<hr />
              <div id="signin_button"> 
                  <a class="action_button button" data-behavior="create_document" name="button" type="submit">
                      Click here to Register and manage your projects.
                      </a>
              </div>
                      
               </div>
			 
		  </div>	   
	  </div><!--End maincontent-->
	  
	  <!--Javascript-->
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	  <script type="text/javascript" src="assets/js/jquery.slicknav.min.js"></script>
      <script type="text/javascript" src="assets/js/pace.min.js"></script>
	  <script>
			$(function(){
				$('#nav').slicknav({
				 label : 'Menu',
				 prependTo : '.mainmenu_area'
				});
			});
		</script>
    </body>
</html>
