<!DOCTYPE html> 
    <head>
		<? include("components/head.inc.php"); ?>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		<div class="help fix">
		  <a href="help.php"><img src="assets/img/help.png" alt=""/></a>
		</div>
		
        <div class="header_area fix">
		  <? include("components/header.inc.php"); ?>
		</div><!--End heading area-->
		
         <div class="maincontent_area fix">
		   <div class="structure">
               <section class="leftpane">  
                   <a href="add-project.php"><img src="assets/img/add-new-project.png" /></a>
               </section>
               <section class="rightpane">
                   <a href="inbox.php">
                   <article class="project_card">
                    this is sharma
                   </article>
                   </a>
                   <article class="project_card">
                    this is sharma
                   </article>
                   <article class="project_card">
                    this is sharma
                   </article>
                   <article class="project_card">
                    this is sharma
                   </article>
                   <article class="project_card">
                    this is sharma
                   </article>
                   <article class="project_card">
                    this is sharma
                   </article>
               </section>
		  </div>	   
	  </div><!--End maincontent-->
	  
	  <!--Javascript-->
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	  <script type="text/javascript" src="js/jquery.slicknav.min.js"></script>
	  <script>
			$(function(){
				$('#nav').slicknav({
				 label : 'Menu',
				 prependTo : '.mainmenu_area'
				});
			});
		</script>
    </body>
</html>
