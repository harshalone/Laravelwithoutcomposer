<div class="header column fix">
    <div class="mainmenu_area fix">
      <div class="logo fix">
        <a href="#"><img class="floatleft fix logoimg" src="assets/img/logo-small.png" alt="Logo"/>
        <h2>Bcamp</h2></a>
      </div>

      <div class="mainmenu fix">
        <ul id="nav">
          <li><a href="index.php">Home</a></li>
          <li><a class="active" href="signin.php">Sigin</a></li>
          <li><a href="register.php">Register</a></li>
          <li><a href="how-it-works.php">How it works</a></li>
          <li class="everyone"><a href="contactus.php">Contact Us</a></li> 
        </ul>
      </div>
        
    
  </div>