<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>BCamp: Online project management system</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
<link rel="stylesheet" href="assets/css/font-awesome.min.css" />
<link rel="stylesheet" href="assets/css/slicknav.css" />
<link rel="stylesheet" href="assets/css/inc.style.css" />
<link rel="stylesheet" href="assets/css/responsive.css" />