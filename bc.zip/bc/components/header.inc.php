<div class="header column fix">
    <div class="mainmenu_area fix">
      <div class="logo fix">
        <a href="#"><img class="floatleft fix logoimg" src="assets/img/logo-small.png" alt="Logo"/>
        <h2>Bcamp</h2></a>
      </div>

      <div class="mainmenu fix">
        <ul id="nav">
          <li><a href="inbox.php">Projects</a></li>
          <li><a href="#">Calender</a></li>
          <li><a href="#">Everything</a></li>
          <li><a href="#">Progress</a></li>
          <li class="everyone"><a href="#">Everyone</a></li>
          <li><a class="active" href="me.php">Me</a></li>
        </ul>
      </div>
       
      <div class="signin_area fix">
       <ul id="singin">
         <li><a href="#">New Features</a></li>
         <li><a href="#">Account</a></li>
         <li><a href="#">Upgrade</a></li>
         <li><a href="#">Signout</a></li>
       </ul>
     </div> 
    </div>

    <div class="search_area fix">
     <div class="search fix">
       <a class="floatleft fix" href="#"><i class="fa fa-search"></i></a>
         <input class="search-text" type="text" placeholder="jump to a project, person,label, or search..">
     </div>
    </div>
    
  </div>